/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul grundriss.c

	Copyright (C) 1995 Claus Rinner

	Version: 2.0 / ATKIS
	Stand: 08.06.1995

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */


#include "grundriss.h"	/* MAX_DOPPEL, MAX_LAPA, grundrisskennzeichen() */
			/* RECHTS, LINKS, BEIDE */
#include "edx.h"	/* datenmodell, IDFORMAT, PFORMAT, OAFORMAT, TRENNER */
#include "fp_edx.h"	/* fp */
#include "edbs.h"	/* lies_whf(), lies_nix(), lies_zahl(), schreibe_satz() */
#include "atkis.h"	/* lies_punkt(), Typ Objektnummer */

#include <string.h>	/* strncpy() */

/*
 *	GLOBALE VARIABLEN
 */

/* Liniengeometrie: */
Punkt	anfang;		/* Grundrisskennzeichen des aktuellen EDBS-Satzes */
Punkt	ende;		/* Endpunkt der aktuellen Liniengeometrie */
int	anzahl_lapa;	/* Anzahl der Interpolationspunkte */
Punkt	lapa[ MAX_LAPA ];	/* die Interpolationspunkte */

/* Zwischenspeicher fuer Linienfunktion bis zum Extrahieren der Liniengeometrie: */
int	anzahl_doppel;			/* Anzahl Linienfunktionen fuer akt. Geometrie */
int	objektart[ MAX_DOPPEL ];	/* fuer die Objektarten der Objekte eines Satzes */
int	folie[ MAX_DOPPEL ];		/* ATKIS-Folie */

Objektnummer
	objekt1[ MAX_DOPPEL ],
	objekt2[ MAX_DOPPEL ];		/* linke/rechte Objektnummer */
int	objektteil1[ MAX_DOPPEL ],
	objektteil2[ MAX_DOPPEL ];	/* linke/rechte Objektteilnummer */
int	richtung[ MAX_DOPPEL ];		/* Linienorientierung RECHTS, LINKS oder BEIDE */
					/* abh. von der Besetzung der Objektnummern-Felder  */

/* Objektinformation: */
/*
 * Folie -> 'folie[0]'
 * Objektart -> 'objektart[0]'
 * Objektnummer -> 'objekt1[0]'
 */
char	objekttyp;	/* _P_unkt, _L_inie, _F_laeche oder _K_omplexes Objekt */
int	art_info;	/* Art der 'Besonderen Information' */
char	text[34];	/* Text der 'Besonderen Information' */
long unsigned int id;	/* temporaerer Speicher fuer berechnete Objekt-ID */


/*
 *	FUNKTIONEN
 */

int linie_funktion( void )
/*
 * Bearbeitet anzahl_doppel mal die Datengruppe "Funktion der Linie".
 * Daten werden global zwischengespeichert.
 */
{
	int i, n;

	for( i=0; i<anzahl_doppel; i++ )
	{
		if( lies_whf() == 1) {
			folie[i] = lies_zahl( 3 );   		/* Folie */
			objektart[i] = lies_zahl( OA_LAENGE );	/* Objektart */
		}
		else {
			fprintf(stderr, "\n\nWHF Linienfunktion != 1\n");
			return -1;
		}

		lies_string( 7, objekt1[i] );	/* Objektnummer 1 (rechts)	*/
		lies_string( 7, objekt2[i] );	/* Objektnummer 2 (links)	*/

		if (! strcmp (objekt1[i], "       "))	/* Nr. rechts frei	*/
			richtung[i] = LINKS;
		else if (! strcmp (objekt2[i], "       "))	/* Nr. links frei	*/
			richtung[i] = RECHTS;
		else {				/* beide Nummernfelder belegt	*/
			richtung[i] = BEIDE;

			/* Nachbarschaft merken - Objektteilnummer beruecksichtigen?	*/
			/* CR 2001-03-10						*/
			fprintf( fp_nachbar, IDFORMAT TRENNER IDFORMAT "\n",
				nummer2id( objekt1[i] ), nummer2id( objekt2[i] ) );
			if( ferror( fp_att ) ) perror( "Fehler beim Schreiben in fp_nachbar\n" );
		}

		objektteil1[i] = lies_zahl( 3 );	/* Objektteilnummer 1 (rechts)	*/
		objektteil2[i] = lies_zahl( 3 );	/* Objektteilnummer 2 (links)	*/

		lies_nix( 2 ); /* Linienteilung1 + Linienteilung2 : nicht verwertet */

		if( (n = lies_whf()) != 0 )	/* fuer Fachparameter	*/
		{
			fprintf(stderr, "\nWHF Fachparameter > 0\n");
			while( n-- )
				lies_nix( 20 );	/* Fachparameter ueberlesen	*/
		}
	}
	return 0;

} /* ******* linie_funktion ******* */


int linie_schreiben( void )
{
	int i, j;

	for( i=0; i<anzahl_doppel; i++ )
	{
		if ((richtung[i] == RECHTS) || (richtung[i] == BEIDE)) {
			/* kein Abspeichern, falls berechnete User-ID zu gross fuer Arc/Info-Datenformat */
			if (nummer2id( objekt1[i] ) > 2147483647) {
				fprintf( stderr, "Berechnete ID " IDFORMAT " fuer Rechtsobjekt -%s- ist zu gross fuer Arc/Info-User-ID\n", nummer2id( objekt1[i] ), objekt1[i]);
				return -1;
			}

			/* Linienzuege mit ID (RECHTS !) in fp schreiben */
			/* erst Linienfunktion */
			fprintf(fp, IDFORMAT TRENNER OTFORMAT TRENNER OAFORMAT TRENNER,
				nummer2id( objekt1[i] ), objektteil1[i], objektart[i] );

			/* dann Geometrie richtig herum */
			fprintf(fp, PFORMAT TRENNER PFORMAT TRENNER, anfang.x, anfang.y);
			for( j=0; j<anzahl_lapa; j++ )
				fprintf(fp, PFORMAT TRENNER PFORMAT TRENNER, lapa[j].x, lapa[j].y);
			fprintf(fp, PFORMAT TRENNER PFORMAT "\n", ende.x, ende.y);

			if( ferror( fp ) ) perror( "Fehler beim Schreiben in fp" );
		}

		if ((richtung[i] == LINKS) || (richtung[i] == BEIDE)) {
			/* kein Abspeichern, falls berechnete User-ID zu gross fuer Arc/Info-Datenformat */
			if (nummer2id( objekt2[i] ) > 2147483647) {
				fprintf( stderr, "Berechnete ID " IDFORMAT " fuer Linksobjekt -%s- ist zu gross fuer Arc/Info-User-ID\n", nummer2id( objekt2[i] ), objekt2[i]);
				return -1;
			}

			/* Linienzuege mit ID (LINKS !) in fp schreiben */
			/* erst Linienfunktion */
			fprintf(fp, IDFORMAT TRENNER OTFORMAT TRENNER OAFORMAT TRENNER,
				nummer2id( objekt2[i] ), objektteil2[i], objektart[i] );

			/* dann Geometrie verkehrt herum */
			fprintf(fp, PFORMAT TRENNER PFORMAT TRENNER , ende.x, ende.y);
			for( j=anzahl_lapa-1; j>=0; j-- )
				fprintf(fp, PFORMAT TRENNER PFORMAT TRENNER, lapa[j].x, lapa[j].y);
			fprintf(fp, PFORMAT TRENNER PFORMAT "\n", anfang.x, anfang.y);

			if( ferror( fp ) ) perror( "Fehler beim Schreiben in fp" );
		}
	}

	return 0;
} /* ******* linie_schreiben ******* */


int linie( void )
/*
 * Speichert Endpunkt der Linie in globaler Var. 'ende'.
 *
 * Liest 'anzahl_doppel' = Anzahl der Funktionen (Objektarten), die
 * fuer diese Linie folgen, z.B. 2, Linie als _Weg_ und zugleich als
 * _Grenze eines Siedlungspolygons_.
 * Laesst von 'linie_funktion()' Folie, Objektart, -nummern fuer
 * rechts und links liegendes Objekt (bei Polygonen) und
 * Objektteilnummern auslesen und global abspeichern.
 *
 * Liest Anzahl der Lageparameter (Interpolationspunkte)
 * und speichert Punkte in 'lapa[]'.
 *
 * Laesst Linie abspeichern ('linie_schreiben()'), falls Art
 * der Liniengeometrie = 11 (Gerade) oder = 15 (Vektor).
 *

 *
 * Returnt 0 falls alles OK, sonst -1.
 */
{
	int i, n;
	int art_geo;	/* Art der Geometrie */

	n = lies_whf();	/* fuer Endpunkt; muss 1 sein */
	if( n == 1 ) ende = lies_punkt();
	else {
		fprintf(stderr, "\nWHF Linienendpunkt != 1\n");
		return -1;
	}

	art_geo = lies_zahl( 2 );
	if( (art_geo != 11) && (art_geo != 15) ) {	/* keine Gerade/Vektor */
		fprintf( stderr, "\nUnbekannte Art der Geometrie = %d\n", art_geo );
		return -1;
	}

	anzahl_doppel = lies_whf();	/* fuer Linienfunktion */
	if( linie_funktion() == -1 )	/* anzahl_doppel mal Datengruppe "Funktion der Linie" */
	{
		fprintf(stderr, "\n\nFehler bei Funktion der Linie\n");
		return -1;
	}
	
	anzahl_lapa = lies_whf();	/* Anzahl der Lageparameter */
	if( anzahl_lapa > MAX_LAPA )
	{
		fprintf(stderr, "\nAnzahl der Lageparameter ist zu gross\n");
		return -1;
	}

	for( i=0; i<anzahl_lapa; i++)	/* Datengruppe "Lageparameter" */
		lapa[i] = lies_punkt();

	return linie_schreiben();	/* Ausgabe in 'fp' */

} /* ******* linie ******* */


int label_schreiben( char typ, int art, long unsigned id )
/*
 * Schreibt den aktuellen Anfangspunkt als Punktgeometrie in fp_points,
 * bzw. bei linien- oder flaechenfoermigen Objekten abhaengig von der
 * Objektart in fp_llx000 oder fp_plx000 (Linien- oder Polygonlabel).
 */
{
	if (typ == 'P')	/* Ausgabe eines Punkt-Objekts in fp_points */
	{
		fprintf(fp_points, IDFORMAT TRENNER PFORMAT TRENNER PFORMAT "\n", id, anfang.x, anfang.y);
		if( ferror( fp_points ) ) perror( "Fehler beim Schreiben in fp_points" );
	}

	if (typ == 'F')	/* Ausgabe eines Polygon-Labels abhaengig von Objektart */
	{
/*		fprintf(fp_plabel, IDFORMAT TRENNER PFORMAT TRENNER PFORMAT "\n", id, anfang.x, anfang.y);	*/
/*		if( ferror( fp_plabel ) ) perror( "Fehler beim Schreiben in fp_plabel" );	*/

		if( datenmodell == ALK ) {
			fp_plx000 = fp_pl_alk;
		} else {
			switch( art / 1000 ) {
			case 1: fp_plx000 = fp_pl1000; break;
			case 2: fp_plx000 = fp_pl2000; break;
			case 3: fp_plx000 = fp_pl3000; break;
			case 4: fp_plx000 = fp_pl4000; break;
			case 5: fp_plx000 = fp_pl5000; break;
			case 6: fp_plx000 = fp_pl6000; break;
			case 7: fp_plx000 = fp_pl7000; break;
			default:fprintf(stderr, "Objektart _%d_ bei Polygonlabelpunkt!!\n", art); return -1;
			}
		}

                fprintf(fp_plx000, IDFORMAT TRENNER PFORMAT TRENNER PFORMAT "\n", id, anfang.x, anfang.y);
		if( ferror( fp_plx000 ) ) perror( "Fehler beim Schreiben in fp_plx000" );

	}

	if (typ == 'L')	/* Ausgabe eines Line-Labels abhaengig von Objektart */
	{
/*		fprintf(fp_llabel, IDFORMAT TRENNER PFORMAT TRENNER PFORMAT "\n", id, anfang.x, anfang.y);	*/
/*		if( ferror( fp_llabel ) ) perror( "Fehler beim Schreiben in fp_llabel" );	*/

		if( datenmodell == ALK ) {
			fp_llx000 = fp_ll_alk;
		} else {
			switch( art / 1000 ) {
			case 1: fp_llx000 = fp_ll1000; break;
			case 2: fp_llx000 = fp_ll2000; break;
			case 3: fp_llx000 = fp_ll3000; break;
			case 4: fp_llx000 = fp_ll4000; break;
			case 5: fp_llx000 = fp_ll5000; break;
			case 6: fp_llx000 = fp_ll6000; break;
			case 7: fp_llx000 = fp_ll7000; break;
			default:fprintf(stderr, "Objektart _%d_ bei Linienlabelpunkt!!\n", art); return -1;
			}
		}

                fprintf(fp_llx000, IDFORMAT TRENNER PFORMAT TRENNER PFORMAT "\n", id, anfang.x, anfang.y);
		if( ferror( fp_llx000 ) ) perror( "Fehler beim Schreiben in fp_llx000" );

	}

	return 0;
} /* ******* label_schreiben ******* */

int objekt_funktion( void )
/*
 * Liest einmal die Datengruppe 'Funktion des Objekts' und
 * speichert die Angaben zu Folie, Objektart, -typ und -nummer
 * in globalen Variablen.
 * Schreibt sie gleichzeitig in fp_objects.
 *
 * Laesst aktuellen Anfangspunkt von 'label_schreiben(...)' in
 * eine von Objekttyp und Objektart abhaengige Datei schreiben.
 *
 * Gibt 0 zurueck, falls alles OK, sonst -1.
 */
{
	folie[0] = lies_zahl( 3 );

	objektart[0] = lies_zahl( 4 );

	lies_nix( 2 );	/* Aktualitaet des Objekts */

	objekttyp = lies_char();

	lies_string( 7, objekt1[0] );
	id = nummer2id( objekt1[0] );

	/* nicht verwertet: */
	lies_nix( 2 );	/* Modelltyp */
	lies_nix( 6 );	/* Entstehungsdatum */
	lies_nix( 1 );	/* Veraenderungskennung */

	/* Abspeichern der allg. Objektinformationen in fp_objects */
	fprintf( fp_objects, IDFORMAT TRENNER "%.7s", id, objekt1[0] );
	fprintf( fp_objects, TRENNER OAFORMAT TRENNER "%c", objektart[0], objekttyp );
	fprintf( fp_objects, TRENNER "%d", folie[0] );
	fprintf( fp_objects, "\n" );
	if( ferror( fp_objects ) ) perror( "Fehler beim Schreiben in fp_objects" );

	/*
	 * Anfangspunkt als Punktgeometrie (Objektart 'P')
	 * oder als Labelpunkt ('L' oder 'F')
	 * in fp_points bzw. fp_llx000 oder fp_plx000 abspeichern.
	 */
	return label_schreiben( objekttyp, objektart[0], id );
} /* ******* objekt_funktion ******* */

int objekt_info( void )
/*
 * Speichert Inhalt des Texts der 'Besonderen Information'
 * (globale Var. 'text') entsprechend der 'art_info' ab.
 */
{
	char	nummer[ 8 ];	/* Objektnummer aus Textfeld */

	switch( art_info ) {
	case 16:
		if( (text[0] == 'H') && (text[1] == 'A') )	/* ALK - Hausnummer */
			fprintf( fp_ha_alk, IDFORMAT TRENNER "%.13s" TRENNER "%.4s" "\n", id, text+2, text+15 );

	case 41:
		/* Text enthaelt Nummer des kompl. Obj., zu dem akt. Objekt gehoert */
		/* nicht abgespeichert, da redundante Information (siehe 'case 42') */
		break;

	case 42:
		/* Text enthaelt Nummer eines der Teilobjekte des akt. kompl. Objekts */
		fprintf( fp_complex, IDFORMAT TRENNER, id );
		/*	fprintf( fp_complex,   "%.7s" TRENNER, text );	*/
		strncpy( nummer, text, 7 ); nummer[ 7 ] = '\0';
		fprintf( fp_complex, IDFORMAT    "\n", nummer2id( nummer ) );
		if( ferror( fp_complex ) ) perror( "Fehler beim Schreiben in fp_complex" );

		break;

	case 44:
		/* kartographische Bezeichnung ab 3. Zeichen in fp_xname ausgeben */
		if( (text[0] == 'G') && (text[1] == 'N') )
		{
			fprintf( fp_gname, IDFORMAT TRENNER, id );
			fprintf( fp_gname,     "%s"    "\n", text+2 );
			if( ferror( fp_gname ) ) perror( "Fehler beim Schreiben in fp_gname" );
		}
		else if( (text[0] == 'K') && (text[1] == 'N') )
		{
			fprintf( fp_kname, IDFORMAT TRENNER, id );
			fprintf( fp_kname,     "%s"    "\n", text+2 );
			if( ferror( fp_kname ) ) perror( "Fehler beim Schreiben in fp_kname" );
		}
		else if( (text[0] == 'Z') && (text[1] == 'N') )
		{
			fprintf( fp_zname, IDFORMAT TRENNER, id );
			fprintf( fp_zname,     "%s"    "\n", text+2 );
			if( ferror( fp_zname ) ) perror( "Fehler beim Schreiben in fp_zname" );
		}

		break;

	case 46:
	case 47:
		/* Ueber- oder Unterfuehrungsreferenz fuer Objekt mit 'art_info' in fp_refer */

		fprintf( fp_refer, IDFORMAT TRENNER  "%2d" TRENNER, id,  art_info );
		/* erste Referenz  (Objektnummer ab text[0], -teilnummer ab text[7])		*/
		/*	fprintf( fp_refer,   "%.7s" TRENNER "%.3s" TRENNER, text,     text+7 );	*/
		strncpy( nummer, text,    7 ); nummer[ 7 ] = '\0';	/* Objektnummer -> ID	*/
		fprintf( fp_refer, IDFORMAT TRENNER "%.3s" TRENNER, nummer2id( nummer ), text+7 );
		/* zweite Referenz (Objektnummer ab text[10], -teilnummer ab text[17])		*/
		/*	fprintf( fp_refer,   "%.7s" TRENNER "%.3s"    "\n", text+10, text+17 );	*/
		strncpy( nummer, text+10, 7 ); nummer[ 7 ] = '\0';	/* Objektnummer -> ID	*/
		fprintf( fp_refer, IDFORMAT TRENNER "%.3s"    "\n", nummer2id( nummer ), text+17 );

		if( ferror( fp_refer ) ) perror( "Fehler beim Schreiben in fp_refer" );

		break;

	case 48:
		/* Text ist leer, ??? */
		break;

	default:
		/* unbekannte Art der Information */
		fprintf( fp_noname, IDFORMAT TRENNER "%2d" TRENNER "%s\n", id, art_info, text );
		if( ferror( fp_noname ) ) perror( "Fehler beim Schreiben in fp_noname" );
		break;
	}

	return 0;
} /* ******* objekt_info ******* */


int geo_angabe( int adg )
/*
 * Liest die Geometrieangabe und speichert gefundene Punkte
 * mit der globalen 'id' und Art der Geometrie in fp_npos
 * (Namenpositionierung) ab.
 */
{
	int n;
	Punkt gp;

	n = lies_whf();	/* Wiederholungsfaktor Datengruppe 'Geometrieangabe' */

	/* evtl. hier switch nach Art der Geometrie (Gerade, Schraffur, ...) */
	if( n > 0 ) fprintf( fp_npos, IDFORMAT TRENNER "%2d", id, adg );

	while( 0 < n-- )
	{
		gp = lies_punkt();
		fprintf( fp_npos, TRENNER PFORMAT TRENNER PFORMAT, gp.x, gp.y );
	}

	fprintf( fp_npos, "\n" );

	return 0;
} /* ******* geo_angabe ******* */


int besondere_info( void )
/*
 * Liest einmal die Datengruppe 'Besondere Information'.
 * Der Text wird in Abhaengigkeit vom Datenelement
 * 'Art der Information' als geographischer, Kurz- oder
 * Zweitname oder als Ueber- oder Unterfuehrungsreferenz
 * oder als Objektnummer eines Teilobjekt eines komplexen
 * Objekts interpretiert und entsprechend abgespeichert.
 *
 * 
 */
{
	int n;
	int adg;	/* Art der Geometrieangabe */

	n = lies_whf();	/* == 1, einmal 'Besondere Information' */
	if( n != 1 )
	{
		fprintf(stderr, "\nWHF Besondere Information != 1\n");
		return -1;
	}

	art_info = lies_zahl( 2 );	/* 'Art der Information' */

	/* nicht verwertet: */
	lies_nix( 2 );	/* Kartentyp */
	lies_nix( 6 );	/* Signaturteilnummer */

	lies_string( 33, text );	/* Datenelement 'Text' */

	/* nicht verwertet: */
	adg = lies_zahl( 2 );	/* Art der Geometrieangabe */
	lies_nix( 3 );	/* Objektteilnummer */

	if( objekt_info() == -1 )
	{
		fprintf( stderr, "\nFehler beim Abspeichern der Objektinformationen\n" );
		return -1;		
	}

	if( geo_angabe( adg ) == -1 )	
	{
		fprintf( stderr, "\nFehler bei Geometrieangabe\n" );
		return -1;		
	}

	return 0;
} /* ******* besondere_info ******* */


int objekt( void )
/*
 * Bearbeitet einmal die 'Funktion des Objekts'.
 * Laesst die Datenelemente von 'objekt_funktion()'
 * auslesen und abspeichern.
 * Verzweigt dann ggfs. n-mal zu 'Besondere Information'
 * bearbeiten ('besondere_info()').
 */
{
	int n;

	n = lies_whf();	/* == 1, einmal Funktion des Objekts */
	if( n != 1 )
	{
		fprintf(stderr, "\nWHF Objektfunktion != 1\n");
		return -1;
	}

	/* Ergebnis in folie[0], objektart[0], objekttyp, objekt1[0] */
	if( objekt_funktion() == -1 )
	{
		fprintf( stderr, "\nFehler bei Funktion des Objekts\n" );
		return -1;		
	}

	n = lies_whf();	/* Wiederholungsfaktor Datengruppe 'Besondere Information' */
	while( 0 < n-- )
	{
		if( besondere_info() == -1 )
		{
			fprintf( stderr, "\nFehler bei Besondere Information\n" );
			return -1;		
		}
	}

	return 0;
} /* ******* objekt ******* */


void grundrisskennzeichen( void )
/*
 * Bearbeitet einmal den kompletten
 * Informationsinhalt des aktuellen
 * EDBS-Satzes (Grundrissdatei).
 */
{
	int n;

	n = lies_whf();	/* i muss 1 sein */
	if(n == 1)
	{
		anfang = lies_punkt();	/* globale Variable */
		lies_nix( 1 );		/* 1 Byte fuer Pruefzeichen, nicht verwertet */
	}
	else {
		fprintf( stderr, "\n\nWHF Grundriss-Koordinate != 1\n" );
		fprintf( stderr, "Der folgende EDBS-Satz wurde nicht bearbeitet:\n" );
		schreibe_satz();
		return;
	}

	n = lies_whf();	/* Datengruppe 'Endpunkt der Linie' und abhaengige */
	while( 0 < n-- )
		if( linie() == -1 )
		{
			fprintf( stderr, "\nACHTUNG, der folgende EDBS-Satz konnte moeglicher" );
			fprintf( stderr, "weise nicht vollstaendig bearbeitet werden:\n" );
			schreibe_satz();
			fprintf( stderr, "\n" );
			return;
		}

	n = lies_whf();	/* Datengruppe 'Funktion des Objekts' und abhaengige */
	while( 0 < n-- )
		if( objekt() == -1 )
		{
			fprintf( stderr, "\nDer folgende EDBS-Satz konnte nicht bearbeitet werden:\n" );
			schreibe_satz();
			return;
		}
} /* ******* grundrisskennzeichen ******* */


