/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul fp_edx.c

	Copyright (C) 1995 Claus Rinner

	Version: 2.0 / ATKIS
	Stand: 19.04.1995

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */

#include <stdio.h>	/* fopen(), fclose() */

#include "fp_edx.h"	/* alle fp's, fp_open(), fp_close() */
#include "edx.h"	/* datenmodell */


#define EDX_PATH "./edx_files/"


/* edx-Ausgabe-Dateien (Definition) */
FILE	*fp, *fp_gebiet, *fp_auftrag,
	*fp_points, *fp_llabel, *fp_plabel, *fp_llx000, *fp_plx000,
	*fp_ll1000, *fp_ll2000, *fp_ll3000, *fp_ll4000,
	*fp_ll5000, *fp_ll6000, *fp_ll7000,
	*fp_ll_alk,
	*fp_pl1000, *fp_pl2000, *fp_pl3000, *fp_pl4000,
	*fp_pl5000, *fp_pl6000, *fp_pl7000,
	*fp_pl_alk,
	*fp_gname, *fp_kname, *fp_zname, *fp_noname, *fp_npos,
	*fp_complex, *fp_refer, *fp_objects, *fp_att,
	*fp_nachbar,
	*fp_ha_alk;


/* Dateizugriff herstellen: ueberall mit Modus "a" (Anhaengen), */
/* ausser fuer 'fp' ("w" fuer Ueberschreiben) */
void fp_open( void )
{
	/* fp: Linien und Polygone zum Verketten durch domino_sort 	*/
	/* wichtig: Oeffnen zum Schreiben "w" (nicht Anhaengen "a"),	*/
	/* weil dom nur die jeweils akt. Linien verketten soll, nicht	*/
	/* frueher abgespeicherte (die wuerden x-mal verkettet, x = 	*/
	/* Position des Quellfiles in Quellfileliste) !!		*/
	fp        = fopen( EDX_PATH "edx_linien", "w");

	fp_gebiet = fopen( EDX_PATH "edx_gebiet",  "a" );
	fp_auftrag= fopen( EDX_PATH "edx_auftrag", "a" );

	/* ALLE punktfoermige Objekte */
	fp_points = fopen( EDX_PATH "edx_punkte",  "a" );
	/* ALLE Linien-Labelpunkte	*/
/*	fp_llabel = fopen( EDX_PATH "edx_llabel",  "a" );	*/
	/* ALLE Polygon-Labelpunkte	*/
/*	fp_plabel = fopen( EDX_PATH "edx_flabel",  "a" );	*/

	fp_ll1000 = fopen( EDX_PATH "edx_ll1000",  "a" );
	fp_ll2000 = fopen( EDX_PATH "edx_ll2000",  "a" );
	fp_ll3000 = fopen( EDX_PATH "edx_ll3000",  "a" );
	fp_ll4000 = fopen( EDX_PATH "edx_ll4000",  "a" );
	fp_ll5000 = fopen( EDX_PATH "edx_ll5000",  "a" );
	fp_ll6000 = fopen( EDX_PATH "edx_ll6000",  "a" );
	fp_ll7000 = fopen( EDX_PATH "edx_ll7000",  "a" );

	fp_ll_alk = fopen( EDX_PATH "edx_ll_alk",  "a" );

	fp_pl1000 = fopen( EDX_PATH "edx_fl1000",  "a" );
	fp_pl2000 = fopen( EDX_PATH "edx_fl2000",  "a" );
	fp_pl3000 = fopen( EDX_PATH "edx_fl3000",  "a" );
	fp_pl4000 = fopen( EDX_PATH "edx_fl4000",  "a" );
	fp_pl5000 = fopen( EDX_PATH "edx_fl5000",  "a" );
	fp_pl6000 = fopen( EDX_PATH "edx_fl6000",  "a" );
	fp_pl7000 = fopen( EDX_PATH "edx_fl7000",  "a" );

	fp_pl_alk = fopen( EDX_PATH "edx_fl_alk",  "a" );

	/* komplexe Objekte : ID, Objektnummer eines Teilobjektes		*/
	fp_complex= fopen( EDX_PATH "edx_komplex", "a" );

	/* Ueber-/Unterf.: ID, Art d. Info, ueber-/unterfuehrter Objektteil	*/
	fp_refer  = fopen( EDX_PATH "edx_referenz","a" );

	fp_gname  = fopen( EDX_PATH "edx_gnamen",  "a" );	/* ID, geographischer Name 	*/
	fp_kname  = fopen( EDX_PATH "edx_knamen",  "a" );	/* ID, Kurzname 		*/
	fp_zname  = fopen( EDX_PATH "edx_znamen",  "a" );	/* ID, Zweitname 		*/

	/* Geometrieangaben zu Namen */
	fp_npos   = fopen( EDX_PATH "edx_nampos",    "a" );

	/* Art der Besonderen Info != 46,47 : ID's, Text der Bes. Info */
	fp_noname = fopen( EDX_PATH "edx_info",  "a" );

	fp_objects= fopen( EDX_PATH "edx_objekte", "a" );	/* Objektinfo aus Rechtszweig		*/

	fp_att    = fopen( EDX_PATH "edx_attribute","a" );	/* Attributdaten 			*/

	/* komplexe Objekte : ID, ID zweier Objekte mit gemeinsamer Line	*/
	/* CR 2001-03-10							*/
	fp_nachbar= fopen( EDX_PATH "edx_nachbar", "a" );

	fp_ha_alk = fopen( EDX_PATH "edx_hausnr",   "a" );	/* ALK - Hausnummern */
}


/* Dateien schliessen */
void fp_close( void )
{
	fclose( fp         ); fclose( fp_points );
	fclose( fp_auftrag ); fclose( fp_gebiet );

/*	fclose( fp_llabel  ); fclose( fp_plabel );	*/

	fclose( fp_ll_alk  );
	fclose( fp_ll1000  ); fclose( fp_ll2000 ); fclose( fp_ll3000 );
	fclose( fp_ll4000  ); fclose( fp_ll5000 ); fclose( fp_ll6000 );
	fclose( fp_ll7000  );

	fclose( fp_pl_alk  );
	fclose( fp_pl1000  ); fclose( fp_pl2000 ); fclose( fp_pl3000 );
	fclose( fp_pl4000  ); fclose( fp_pl5000 ); fclose( fp_pl6000 );
	fclose( fp_pl7000  );

	fclose( fp_complex ); fclose( fp_refer  );

	fclose( fp_gname   ); fclose( fp_kname  ); fclose( fp_zname  );
	fclose( fp_noname  ); fclose( fp_npos   );

	fclose( fp_objects );
	fclose( fp_att     );

	fclose( fp_nachbar );

	fclose( fp_ha_alk );

	if( datenmodell == ALK ) {
		remove( EDX_PATH "edx_attribute" );
	} else {
		remove( EDX_PATH "edx_hausnr" );
	}
}

