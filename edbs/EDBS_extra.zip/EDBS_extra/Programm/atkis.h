/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul atkis.c

	Copyright (C) 1995 Claus Rinner

	Version: 2.0 / ATKIS
	Stand: 19.04.1995

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */


#ifndef _EXTRA_ATKIS_H
#define _EXTRA_ATKIS_H


/*
 *	Typdeklarationen
 */
typedef double Koordinate;	/* weil atof() in lies_punkt() double liefert */
typedef struct { Koordinate x, y; } Punkt;
typedef char Objektnummer[8];


Punkt lies_punkt( void );
/*
 *	liest ab der aktuellen Position in 'satz'
 *	Numerierungsbezirk und relativen Rechts- und
 *	Hochwert (= 20 Zeichen, ALK/ATKIS-Format), und
 *	schreibt Gauss-Krueger-Koordinaten ins Feld 'p'.
 */


#endif	/* _EXTRA_ATKIS_H */
