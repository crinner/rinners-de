/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul edbs.c

	Copyright (C) 1995 Claus Rinner

	Version: 2.0 / ATKIS
	Stand: 08.06.1995

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */


#include <string.h>	/* strlen(), strcpy(), strncpy(), gets(), strcmp() */
#include <stdlib.h>	/* atoi() */
#include <stdio.h>	/* fprintf(), stderr */

/* alle Auftragsarten, MAX_SATZLAENGE, MAX_FORTSATZ,		*/
/* lies_satz(), schreibe_satz(), lies_string(), lies_zahl(),	*/
/* lies_whf(), lies_nix(), lies_char(), lies_edbs()		*/
#include "edbs.h"


EDBS_Satz satz;		/* aktueller EDBS-Satz */
int  pos = 0;		/* aktuelle Position im satz */

int	satz_zaehler = 0;	/* Anzahl gelesener Saetze */
int     satz_laenge = 0;	/* Laenge in Zeichen des akt. EDBS-Satzes */
char	zugehoerig = ' ';	/* Zugehoerigkeitsschluessel */


int lies_satz( void )
/*
 * Liest naechsten EDBS-Satz in satz ein.
 * Setzt satz_laenge auf 36 und pos auf 0.
 * Liefert 0, falls Inputfehler.
 * Liefert String-Laenge von satz sonst.
 */
{
	if( !gets( satz ) )
		return 0;

	satz_laenge = 36;
	pos = 0;

	return strlen( satz );
} /* ******* lies_satz ******* */


int lies_fortsatz( void )
/*
 * Liest naechsten EDBS-Satz in fsatz ein.
 * Setzt pos auf 0 (satz_laenge wird in lies_satzart erhoeht).
 * Haengt Inhalt der Information von fsatz (ab Position 36)
 * hinten an satz (ab Position satz+satz_laenge) an.
 * Kopiert Pos. 0-35 von fsatz ueber 0-35 von satz.
 * 
 * Liefert 0, falls Inputfehler.
 * Liefert String-Laenge von fsatz sonst.
 */
{
	char fsatz[ MAX_SATZLAENGE ];
	int laenge;

	if( !gets( fsatz ) )
		return 0;

	pos = 0;

	laenge = strlen( fsatz );
	if( satz_laenge + laenge -36 > MAX_FORTSATZ * MAX_SATZLAENGE )
	{
		fprintf( stderr, "\nSpeicher reicht nicht fuer alle Folgesaetze\n" );
		return UNDEFINIERT;
	}

	strncpy( satz, fsatz, 36 );

	strcpy( satz + satz_laenge, fsatz + 36 );

	return laenge;
} /* ******* lies_fortsatz ******* */


void schreibe_satz( void )
/*
 * Schreibt den kompletten satz auf stderr.
 */
{
	fprintf( stderr, satz );
} /* ******* schreibe_satz ******* */


void lies_string( int n, char *ziel )
/*
 * Liest n Zeichen aus satz ab Position pos.
 * Schreibt sie in ziel[0..n-1].
 * Schreibt '\0' in ziel[n].
 * Daher muss ziel mindestens char[n+1] sein.
 * Setzt pos auf pos+n.
 */
{
	strncpy( ziel, satz+pos, n );
	pos += n;
	ziel[ n ] = '\0';
} /* ******* lies_string ******* */


int lies_zahl( int n )
/*
 * Liefert die naechsten n Zeichen in satz als ganze Zahl.
 */
{
	char ziel[ MAX_SATZLAENGE ];

	lies_string( n, ziel );

	return atoi( ziel );
} /* ******* lies_zahl ******* */


int lies_whf( void )
/*
 * Liefert die naechsten n Zeichen in satz als 4stellige ganze Zahl.
 */ 
{
	int whf = lies_zahl( 4 );

	if( whf > 200 )
		fprintf( stderr, "WHF > 200 koennte fehlerhaft sein." );

	return whf;
} /* ******* lies_whf ******* */


void lies_nix( int n )
/*
 * Zaehlt den Positionszeiger pos fuer satz um n hoch.
 */
{
	pos += n;
} /* ******* lies_nix ******* */


char lies_char( void )
/*
 * Liefert naechstes Zeichen aus satz.
 */
{
	char ziel[ 2 ];

	lies_string( 1, ziel );

	return ziel[ 0 ];
} /* ******* lies_char ******* */


int ist_edbs( void )
/*
 * Liest (die ersten) vier Zeichen aus satz.
 * Liefert 0, falls ungleich "EDBS", sonst 1.
 */
{
	char anfang[ 5 ];

	lies_string( 4, anfang );

	return strcmp( anfang,"EDBS" ) == 0;
} /* ******* ist_edbs ******* */


int vgl_satzinfo( char op[ 5 ], char in[ 9 ] )
/*
 * Liefert Flag fuer EDBS-Satzart je nach Operation op und Infoname in.
 */
{
	if( !strcmp(op, "BSPE") || !strcmp(op, "FEIN") )
	{
		if( strcmp(in, "ULOBNN  ")==0 ) return OBJEKTDATEN;
		if( strcmp(in, "ULTANN  ")==0 ) return ATTRIBUTE;
	}
	if( !strcmp(op, "BINF") && !strcmp(in, "ULOTEX  "))
		return AUFTRAGSKENNDATEN;
	if( !strcmp(op, "OTEX") && !strcmp(in, "ULOTEX  "))
		return AUFTRAGSTEXTDATEN;
	if( !strcmp(op, "BKRT") && !strcmp(in, "IBENKRT "))
		return GEBIETSKENNZEICHNUNG;
	if( !strcmp(op, "AKND") && !strcmp(in, "ULQA0000"))
		return AUFTRAGSKENNSATZ;
	if( !strcmp(op, "AEND") )
		return AUFTRAGSENDE;

	fprintf( stderr, "\nOperation _%s_, Infoname _%s_: Auftragsart unbekannt\n", op, in);
	return UNDEFINIERT;
} /* ******* vgl_satzinfo ******* */


int lies_satzart( char * zugeh )
/*
 * Ruft EDBS-Test auf; erhoeht satz_zaehler, falls EDBS-Satz vorliegt.
 * Liest Satzlaenge und erhoeht satz_laenge um Laenge des Informationsinhalts.
 * Liest Zugehoerigkeitsschluessel (Rueckgabe als Referenzparameter zugeh).
 * Liest Operation und Infoname.
 * Liefert Ergebnis von vgl_satzinfo().
 */
{
	char operation[ 5 ], infoname[ 9 ];
	int art;

	if(! ist_edbs() )		/* Satzanfang */
	{
		fprintf( stderr, "\nInput ist kein EDBS-Satz\n" );
		return UNDEFINIERT;
	}

	satz_zaehler++;

	/* Satzlaenge lesen (gezaehlt ab Pos. 13), Laenge des Headers (36) abziehen	*/
	/* ergibt: Erhoehung von satz_laenge um Laenge des "Inhalts der Information"	*/
	satz_laenge += (12 + lies_zahl( 4 ) -36);

	lies_nix( 4 );			/* Anfangsadresse Suchkriterium */
	lies_string( 4, operation );	/* Operation */
	lies_nix( 6 );			/* EDBS-Satznummer */
	*zugeh = lies_char();		/* Zugehoerigkeitsschluessel */
	lies_nix( 1 );			/* Editierschluessel */
	lies_nix( 4 );			/* Quittungsschluessel */
	lies_string( 8, infoname );	/* Name der Information */

	art = vgl_satzinfo( operation, infoname );

	return art;
} /* ******* lies_satzart ******* */


int lies_edbs( void )
/*
 * Liest naechsten EDBS-Satz. Falls misslungen, Programmabbruch;
 * d.h. in main() kontrollieren, ob noch Saetze vorhanden.
 * Laesst Satzart und Z-Schluessel auslesen.
 * Laesst F-Saetze lesen, falls Z_Schluessel 'A' und solange 'F'.
 * Falls letzter Z_Schluessel nicht 'E', UNDEFINIERT liefern.
 * Ebenso, falls Satzart bei F-Saetzen wechselt.
 * Ebenso, falls Z-Schluessel weder ' ' noch 'A'.
 * Sonst liefere satzart.
 */
{
	int satzart, fsatzart;
	char zugehoerig;

	if( !lies_satz() )
	{
		fprintf( stderr, "\nInputfehler, keine Eingabe lesbar\n" );
		return ABBRUCH;
	}
	satzart = lies_satzart( &zugehoerig );

	if( zugehoerig == 'A' )
	{
		lies_fortsatz();
		fsatzart = lies_satzart( &zugehoerig );

		while( (zugehoerig == 'F') && (fsatzart == satzart) )
		{
			lies_fortsatz();
			fsatzart = lies_satzart( &zugehoerig );
		}

		if( fsatzart != satzart )
		{
			fprintf( stderr, "\nSatzart wechselt in Fortsetzungssaetzen\n" );
			return UNDEFINIERT;
		}

		else if( zugehoerig != 'E' )
		{
			fprintf( stderr, "\nKein Endesatz fuer Fortsetzungssaetze\n" );
			return UNDEFINIERT;
			/* Achtung: In diesem Fall koennen der A-Satz, alle evtl. folgenden F-	*/
			/* Saetze UND DER DARAUFFOLGENDE NICHT-E-SATZ nicht bearbeitet werden.	*/
			/* D.h., bedingt durch das Zusammenschmelzen der Fortsetzungssaetze in	*/
			/* lies_fortsatz() geht ein "unbeteiligter" Satz verloren.		*/
		}
	}

	else if( zugehoerig != ' ' )
	{
		fprintf( stderr, "\nEDBS-Folge- oder Endesatz ohne Anfangssatz\n" );
		return UNDEFINIERT;
	}

	return satzart;
} /* ******* lies_edbs ******* */

/* Ende edbs.c */
