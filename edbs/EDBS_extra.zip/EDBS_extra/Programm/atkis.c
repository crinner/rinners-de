/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul atkis.c

	Copyright (C) 1995 Claus Rinner

	Version: 2.0 / ATKIS
	Stand: 08.06.1995

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */


#include <stdlib.h>	/* atof() */

#include "atkis.h"	/* Typ Punkt, lies_punkt() */
#include "edbs.h"	/* lies_string(), lies_nix() */
#include "edx.h"	/* datenmodell */


Punkt lies_punkt( void )
/*
 *	liest ab der aktuellen Position in 'satz'
 *	Numerierungsbezirk und relativen Rechts- und
 *	Hochwert (= 20 Zeichen, ALK/ATKIS-Format), und
 *	schreibt Gauss-Krueger-Koordinaten ins Feld 'p'.
 */
{
	Punkt p;

	p.x = 100000.0 * lies_zahl( 2 );	/* NBZ [100 km] */
	p.y = 100000.0 * lies_zahl( 2 );

	if( datenmodell == ALK) {
		p.x = p.x + 1000.0 * lies_zahl( 2 );	/* NBZ ALK [1 km] */
		p.y = p.y + 1000.0 * lies_zahl( 2 );

		p.x = p.x + 0.001 * lies_zahl( 6 );	/* rel. Rechtswert [1 mm] */
		p.y = p.y + 0.001 * lies_zahl( 6 );	/* rel. Hochwert   [1 mm] */
	} else {
		p.x = p.x + 10000.0 * lies_zahl( 1 );	/* NBZ ATKIS [10 km] */
		lies_nix( 1 );				/* Leerzeichen */
		p.y = p.y + 10000.0 * lies_zahl( 1 );
		lies_nix( 1 );

		p.x = p.x + 0.01 * lies_zahl( 6 );	/* rel. Rechtswert [1 cm] */
		p.y = p.y + 0.01 * lies_zahl( 6 );	/* rel. Hochwert   [1 cm] */
	}

	return p;

} /* ******* lies_punkt() ******* */
