/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul edx.h

	Copyright (C) 1995 Claus Rinner

	Version: 2.0 / ATKIS + ALK
	Stand: 26.04.1995

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */


#ifndef _EXTRA_EDX_H
#define _EXTRA_EDX_H


#include <stdio.h>	/* struct FILE */

/*	keine lokalen #includes, weil edx.h in der Modulhierarchie top ist.	*/


/*
 *	allgemeine #defines
 */

#define TRENNER		", "	/* Trennzeichen fuer Ausgaben		*/
#define TRENNER_LAENGE	2

#define IDFORMAT	"%10lu"	/* Format fuer Objekt-ID			*/
#define ID_LAENGE	10	/* Anzahl Zeichen, innerhalb derer die		*/
				/* Objekt-ID rechtsbuendig geschrieben wird,	*/
				/* und die fuer die Objekt-ID ausgelesen werden.*/

#define OAFORMAT	"%4d"	/* Format fuer Objektart		*/
#define OA_LAENGE	4

#define OTFORMAT	"%3d"	/* Format fuer Objektteilnummer		*/
#define OT_LAENGE	3


/* fuer Variable 'datenmodell': */
#define ALK	5
#define ATKIS	25

extern int datenmodell;	/* implementiert in edbs.c */

/* abhaengig vom 'datenmodell': */
extern int KO_LAENGE;	/* 11 fuer ALK, 10 fuer ATKIS */

/* leider unabhaengig vom 'datenmodell': */
#define PFORMAT "%.3f"


/*
 *	Funktionen
 */

long unsigned int nummer2id( char* nr );
/*
 *	konvertiert 5 letzten Zeichen aus aktuelle_nummer
 *	in long unsigned integer
 *	Grund fuer die Beschraenkung auf 5 Zeichen:
 *	ARC/INFO - Data Models, Concepts & Key Terms, Seite B-3:
 *		"User-IDs are stored as 4-byte binary integers
 *		and can range from +-1 to +-2147483647."
 */


#endif	/* _EXTRA_EDX_H */
