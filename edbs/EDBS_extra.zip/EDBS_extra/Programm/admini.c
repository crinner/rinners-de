/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul admini.c

	Copyright (C) 1995 Claus Rinner

	Version: 2.0 / ATKIS
	Stand: 08.06.1995

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */


#include <stdio.h>	/* fprintf(), ferror(), perror() */
#include <string.h>	/* strcpy() */

#include "edx.h"	/* PFORMAT, TRENNER, datenmodell */
#include "atkis.h"	/* Typ Punkt, lies_punkt() */
#include "edbs.h"	/* lies_nix(), lies_string() */
#include "admini.h"	/* gebietskennzeichnung(), auftragstext(), auftragskennung() */
#include "fp_edx.h"	/* fp_gebiet, fp_auftrag */


int datenmodell;	/* ALK oder ATKIS */


void gebietskennzeichnung( void )
{
	Punkt lu, ro;	/* linke untere, rechte obere Blattecke	*/

	lu = lies_punkt();
	ro = lies_punkt();

	fprintf( fp_gebiet, PFORMAT TRENNER PFORMAT TRENNER, lu.x, lu.y );
	fprintf( fp_gebiet, PFORMAT TRENNER PFORMAT "\n", ro.x, ro.y );

	if( ferror( fp_gebiet ) ) perror( "Fehler beim Schreiben in fp_gebiet\n" );
}

void auftragstext( void )
/*
 * Liest 18 Zeichen Auftragstextdaten und speichert sie in fp_text ab.
 */
{
}

void auftragskennung( void )
/*
 * Liest aus dem EDBS-Auftragskennsatz (AKND, ULQA0000) die
 * Datenelemente 'Datenkennung-ALK' und 'Datenkennung-DLM'
 * und belegt die Variable 'datenmodell'.
 */
{
	char kennung_alk[3], kennung_atkis[3], text[33];

	if( lies_whf() != 1 ) {
		fprintf( stderr, "Datengruppe 'Auftragskenndaten' kommt != 1-mal vor." );
		exit( 1 );
	}
	lies_string( 14, text );	/* Dienststelle */
	fprintf( fp_auftrag, "%s", text );
	lies_nix( 5 );	/* Auftragsnummer */
	lies_nix( 1 );	/* weitere Gliederung */

	lies_nix( 1 );	/* Pruefzeichen */
	lies_nix( 1 );	/* Auftragsart */
	lies_nix( 2 );	/* Aktualitaet des Auftrags */
	lies_nix( 1 );	/* Integrationshinweis */

	lies_nix( 2 );	/* Nummer der BGDB */

	lies_nix( 11 );	/* Antragshinweis */

	lies_nix( 1 );	/* Auftragskennung */
	lies_nix( 8 );	/* Benutzungs-/Fortf.-art */
	lies_string( 32, text );	/* Text fuer die Ausgabe */
	fprintf( fp_auftrag, TRENNER "%s", text );
	lies_nix( 2 );	/* Verarbeitungsmodus */
	lies_nix( 2 );	/* Anzahl Ausfertigungen */

	lies_nix( 2 );	/* Punktdatenkennung */

	lies_string( 2, kennung_alk );	/* Datenkennung-ALK */

	lies_nix( 2 );	/* Messungselementekennung */

	lies_string( 2, kennung_atkis ); /* Datenkennung-DLM */

	/* ************************************************************************ */
	/* Auskommentiert am 29.5.96 wg. Problem der Erkennung von EDBS/ATKIS-Input */
	/* ************************************************************************ */
	/* if( strcmp( kennung_atkis,"  " ) != 0 ) {
		fprintf( stderr, "EBDS-Datei enthaelt ATKIS-Daten\n" ); */
		datenmodell = ATKIS;
	/* }
	else if( strcmp( kennung_alk,"  " ) != 0 ) {
		fprintf( stderr, "EBDS-Datei enthaelt ALK-Daten\n" );
		datenmodell = ALK;
	}
	else {
		fprintf( stderr, "Datenmodell (ALK oder ATKIS) konnte nicht identifiziert werden." );
		exit( 1 );
	} */

	lies_nix( 2 );	/* Datenkennung-DKM */
	lies_nix( 50 );	/* unbelegt */

	lies_nix( 1 );	/* Meridianstreifensystem der Ausgabe */
	lies_nix( 1 );	/* Verarbeitungsstop */

	lies_nix( 3 );	/* Verarbeitungsstatus */

	lies_nix( 6 );	/* hoechste weitere Satznummer */
	lies_string( 6, text );	/* Anzahl der weiteren Saetze */
	fprintf( fp_auftrag, TRENNER "%s", text );

	lies_string( 6, text );	/* Datum Ersteintrag */
	fprintf( fp_auftrag, TRENNER "%s", text );
	lies_string( 6, text );	/* Datum Modifikation */
	fprintf( fp_auftrag, TRENNER "%s", text );
	lies_string( 6, text );	/* Datum Ausgabe */
	fprintf( fp_auftrag, TRENNER "%s", text );

	lies_nix( 14 );	/* zustaendige Stelle */
	lies_nix( 12 );	/* Plausibilitaetssteuerung */
	lies_nix( 1 );	/* Hinweis fuer Geometriebehandlung */

	lies_nix( 8 );	/* Folgeverarbeitung */
	lies_nix( 8 );
	lies_nix( 8 );
	lies_nix( 8 );

	lies_nix( 1 );
	lies_nix( 10 );
	lies_nix( 10 );

	fprintf( fp_auftrag, "\n" );
}
