/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul alk.c

	Copyright (C) 1995 Claus Rinner

	Version: 2.0 / ALK
	Stand: 10.04.1995

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */

/* NB: in Funktion lies_punkt() wurde die Sequenz
	lies_string(2,f); p.x=10.0*atof(f); ersetzt durch
	p.x=10.0*lies_zahl(2);
	Es ist zu ueberpruefen, ob der richtige Typ
	herauskommt (double).
 */

#include <stdlib.h>	/* atof() */

#include "alk.h"	/* Typ Punkt, lies_punkt() */
#include "edbs.h"	/* lies_string(), lies_nix() */


Punkt lies_punkt( void )
/*
 *	liest ab der aktuellen Position in 'satz'
 *	Numerierungsbezirk und relativen Rechts- und
 *	Hochwert (= 20 Zeichen, ALK-Format), und
 *	schreibt Gauss-Krueger-Koordinaten ins Feld 'p'.
 */
{
	Punkt p;

	p.x = 100000.0 * lies_zahl( 2 );	/* NBZ [100 km] */
	p.y = 100000.0 * lies_zahl( 2 );

	p.x = p.x + 1000.0 * lies_zahl( 2 );	/* NBZ   [1 km] */
	p.y = p.y + 1000.0 * lies_zahl( 2 );

	p.x = p.x + 0.001 * lies_zahl( 6 );	/* rel. Rechtswert [1 mm] */
	p.y = p.y + 0.001 * lies_zahl( 6 );	/* rel. Hochwert   [1 mm] */

	return p;
} /* ******* lies_punkt() ******* */
