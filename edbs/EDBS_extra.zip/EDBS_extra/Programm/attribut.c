/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul attribut.c

	Copyright (C) 1995 Claus Rinner

	Version: 2.0 / ATKIS
	Stand: 17.03.1995

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */


#include <stdlib.h>	/* atoi() */
#include <stdio.h>	/* fprintf(), ferror(), perror() */

#include "attribut.h"	/* attributkennzeichen() */
#include "edx.h"	/* IDFORMAT, TRENNER, nummer2id() */
#include "atkis.h"	/* Objektnummer */
#include "edbs.h"	/* lies_whf(), lies_string(), lies_nix() */
#include "fp_edx.h"	/* fp_att */


void attributkennzeichen( void )
/*
 * bearbeitet einmal den kompletten
 * Informationsbereich des aktuellen
 * EDBS-Satzes (Attributdatei)
 */
{
	int i;
	char att_typ[5], att_wert[8];
        Objektnummer obj_nr, teil_nr;

	i = lies_whf();			/* i muss 1 sein 	*/
	if (i != 1)
	{
		fprintf( stderr, "WHF Attributkennzeichen != 1\n" );
		return;
	}

	lies_string(7, obj_nr);		/* Objektnummer 	*/
	lies_string(3, teil_nr);	/* Objektteilnummer 	*/
	lies_nix( 1 );			/* Pruefzeichen 	*/
	lies_nix( 2 );			/* Aktualitaet 		*/

	i = lies_whf();			/* Datengruppe Attribut	*/
	
	while( i-- > 0 )
	/* auch Attributsaetze ohne Datengruppe Attribut kommen vor */
	{
		lies_string( 4, att_typ );
		lies_string( 7, att_wert );

		fprintf( fp_att, IDFORMAT TRENNER "%3d" TRENNER "%.4s" TRENNER "%7d" "\n",
				nummer2id( obj_nr ), atoi( teil_nr ), att_typ, atoi( att_wert ) );
		if( ferror( fp_att ) ) perror( "Fehler beim Schreiben in fp_att\n" );
	}
}
/* attributkennzeichen() */

