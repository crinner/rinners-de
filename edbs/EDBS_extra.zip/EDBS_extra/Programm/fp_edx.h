/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul fp_edx.c

	Copyright (C) 1995 Claus Rinner

	Version: 2.0 / ATKIS
	Stand: 19.04.1995

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */


#ifndef _EXTRA_FP_EDX_H
#define _EXTRA_FP_EDX_H


#include <stdio.h>	/* struct FILE */


/* edx-Ausgabe-Dateien (Deklaration) */
extern FILE *fp,	/* Linien(stuecke)				*/
	*fp_auftrag,	/* Auftragskenndaten				*/
	*fp_gebiet,	/* l.u. und r.o. Blatteckpunkt			*/
	*fp_points,	/* Topographie aus Rechtszweigen: Punktobjekte	*/

	*fp_llabel, *fp_plabel,	/* Topographie-Info aus Rechtszweigen:	*/
			/* Labelpkte von Linien und Flaechen (gemischt)	*/
			/* und nach Objektart getrennt:			*/
	*fp_ll_alk,
	*fp_ll1000, *fp_ll2000, *fp_ll3000, *fp_ll4000,
	*fp_ll5000, *fp_ll6000, *fp_ll7000,
	*fp_llx000,	/* temporaerer file pointer fuer Linienlabel	*/
	*fp_pl_alk,
	*fp_pl1000, *fp_pl2000, *fp_pl3000, *fp_pl4000,
	*fp_pl5000, *fp_pl6000, *fp_pl7000,
	*fp_plx000,	/* temporaerer file pointer fuer Flaechenlabel	*/

	*fp_complex,	/* Bestandteile der komplexen Objekte		*/
	*fp_refer,	/* Ueber-/Unterfuehrungsreferenzen		*/

	/* geographische, Kurz- & Zweitnamen aus Rechtszweigen		*/
	*fp_gname, *fp_kname, *fp_zname,

	/* Text aus Rechtszweig, der nicht mit "GN", "KN" oder "ZN"	*/
	/* beginnt, sowie nicht zu e. komp-lexen Objekt gehoert, und	*/
	/* keine Ueber-/Unterfuehrungsreferenz darstellt.		*/
	*fp_noname,

	*fp_npos,	/* Position der Namen aus Rechtszweigen		*/

	*fp_objects,	/* Eine Zeile jedes Objekt aus Rechtszweig:	*/
			/* Objektart, -nummer, -ID, -typ, Folie		*/
	*fp_att,	/* Attributtypen und -werte = Auspraegungen	*/
	*fp_nachbar,	/* benachbarte Objekte				*/
	*fp_ha_alk;	/* ALK - Hausnummern */


/* Dateizugriff herstellen: */
void fp_open( void );

/* Dateien schliessen */
void fp_close( void );


#endif	/* _EXTRA_FP_EDX_H */
