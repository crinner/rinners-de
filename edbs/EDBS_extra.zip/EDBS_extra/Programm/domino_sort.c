/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul domino_sort.c

	Copyright (C) 1995 Claus Rinner

	Version: 2.1 / ATKIS + ALK
	Stand: 08.06.1995

	Aenderung: 
	- Beruecksichtigung der ObjektTEILnummer !!!

	Kurzbeschreibung:
	- Sortiert Reihe von Folgen von Koordinatenpaaren
	  und verkettet sie zu Polygonen, bzw. erkennt Linien.
	- Erwartetes Input-Format: Folge von Saetzen der Form
	  Objekt-ID (ID_LAENGE Zeichen), Objektteilnummer (OT_LAENGE),
	  Objektart (OA_LAENGE), X-Koordinate (11), Y-Koordinate (11),
	  X (11), Y (11), X (11), Y (11), ...
	- Feld-Trennung durch 'TRENNER' aus edx.h, Satz-Trennung durch newline

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */

#include "edx.h"	/* fuer	datenmodell, OA_LAENGE, OA_FORMAT, PFORMAT,	*/
			/* TRENNER, TRENNER_LAENGE, ...	*/
#include "atkis.h"	/* fuer Punkt					*/
#include "edbs.h"	/* fuer lies_string(), lies_zahl()		*/

#include <stdlib.h>	/* fuer atoi()		*/
#include <string.h>	/* wg. strncpy()	*/
#include <stdio.h>	/* wg. gets()		*/


#define MAX_VERTEX	2000	/* max. Anzahl verarbeitbarer Interpolationspunkte pro Linie */
#define MAX_TEILE	2000    /* */


typedef Punkt Linie[ MAX_VERTEX ];

typedef struct {
	Linie knoten;	/* fuer eine Reihe von Koordinatenpaaren 	*/
	int anzahl;	/* Anzahl der Paare = Vertices           	*/
	int verkettet;	/* flag fuer linien_verketten,           	*/
			/* 1 -> hat bereits irgendwo reingepasst 	*/
	} nLinie;

typedef struct {
	int index;	/* Vorkommen in der domino-sortierten Reihe    */
	int richtung;	/* VOR/RUECKWAERTS je nach Beginn mit Anfangs- */
			/* oder Endpunkt                               */
	} IndexRichtung;

int linien_zaehler;	/* zaehlt eingelesene Linienzuege (Punktfolgen) mit gleicher Objekt-ID	*/
int anzahl_verkettet=0;	/* zaehlt die momentan verketteten Linien	*/

int objektart = -1;		/* ATKIS-Objektart	*/
long unsigned neue_id, aktuelle_id = -1;
				/* ATKIS-Objektnummer (7 chars), von edx in int umgerechnet	*/
int neue_tn, aktuelle_tn = -1;	/* ObjektTEILnummer	*/

nLinie objektteil[MAX_TEILE];	/* ein Feld, dessen Komponenten Linienzuege sind		*/


#define DOM_PATH "./dom_files/"

#define VORWAERTS   0	/* Linie (= Objektteil) wird mit Anfangs-	*/
#define RUECKWAERTS 1	/* bzw. Endpunkt zuerst angekettet		*/

#define RECHTS 0
#define LINKS  1


/* soll Indizes der domino-sortierten Linien enthalten */
IndexRichtung reihenfolge[2*MAX_TEILE + 1];

/* Dateien fuer Sortier-Ergebnis */
FILE *fp_err, *fp_polygons, *fp_poly, *fp_line;
FILE *fp_l_alk, *fp_l0,
     *fp_l2, *fp_l3, *fp_l4, *fp_l5, *fp_l6, *fp_l7;
FILE *fp_p_alk, *fp_p0,
     *fp_p2, *fp_p3, *fp_p4, *fp_p5, *fp_p6, *fp_p7;
FILE *fp_lx, *fp_px;


extern EDBS_Satz satz;	/* aktueller Eingabe-Satz: 'satz' aus edbs.c		*/
extern int pos;		/* aktuelle Position in 'satz': 'pos' aus edbs.c	*/



int liefere_code( void )
{
	int fkt;

	fkt = lies_zahl( OA_LAENGE );	/* arbeitet mit 'pos' auf 'satz' !!	*/
	lies_nix( TRENNER_LAENGE );

	return fkt;
} /***** ENDE liefere_code() *****/


void lies_punkte( int teil )
/*
 *	Es wird vorausgesetzt, dass *pos auf der ersten Ziffer
 *	der ersten Koordinate des ersten Punktes steht.
 *	Dann liest 'lies_punkte()' die Koordinatenpaare aus einer
 *	Zeile (='satz') der Standardeingabe, beginnend bei Position
 *	'*pos', und schreibt diese Punktfolge in die 'teil'te
 *	Position des Vektors 'objektteil[]', in die Komponente 'knoten'.
 *	Die Anzahl der Punkte wird in 'objektteil[].anzahl'
 *	vorgehalten.
 */
{
	int vertex_zaehler = 0;	/* Anzahl gelesener Stuetzpunkte der Linie	*/
	char xy[ 11+1 ];	/* Koordinate temporaer als String; 12 wg. ALK	*/

	while (pos <= strlen(satz))
	{
		lies_string( 11, xy );
		objektteil[ teil ].knoten[ vertex_zaehler ].x = atof( xy );
		lies_nix( TRENNER_LAENGE );

		lies_string( 11, xy );
		objektteil[ teil ].knoten[ vertex_zaehler ].y = atof( xy );
		lies_nix( TRENNER_LAENGE );

		vertex_zaehler++;
	}
	objektteil[ teil ].anzahl = vertex_zaehler;

} /* lies_punkte() */


void lies_id( void )
/*
 *	Liest die naechsten ID_LAENGE Zeichen
 *	und liefert sie im globalen Integer neue_id zurueck.
 */
{
	neue_id = lies_zahl( ID_LAENGE );
	lies_nix( TRENNER_LAENGE );

	neue_tn = lies_zahl( OT_LAENGE );
	lies_nix( TRENNER_LAENGE );
}


void init_globals( void )
/*
 *	Initialisierung bei Objektwechsel.
 *	Liest neue Objekt-ID und -art und erste Linie (Punktfolge).
 */
{
	aktuelle_id = neue_id;	/* , welche zu Beginn der main-while-Schleife gelesen wurden	*/
	aktuelle_tn = neue_tn;

	pos = ID_LAENGE + TRENNER_LAENGE + OT_LAENGE + TRENNER_LAENGE;

	objektart = liefere_code();

	anzahl_verkettet = 0;

	lies_punkte( 0 );
	linien_zaehler = 1;

} /* init_globals */


void linien_verketten (void)
/* Sortiert die zur aktuellen Objekt-ID	+ OTN		*/
/* im Feld objektteil[] gespeicherten Linienzuege nach  */
/* zusammenpassenden End- und Anfangspunkten            */
/* -> "Domino-Sortierung"				*/
{
	#define ERSTE (0)	/* beginne Kette mit Linie 0 */

	int i, iterationen=0;
	int lindex, rindex;	/* Anfangs-, End-Index in reihenfolge[] */
	Punkt anfang, ende;	/* momentan erster, letzter Punkt der Kette */

	for (i=0; i<linien_zaehler; i++)
		objektteil[i].verkettet = 0; /* noch nichts sortiert */

	/* 1.Annahme: Es kommt nicht auf die Startlinie an, */
	/* da alle Objektteile zusammenpassen.. .  .   .    */

	/* 2.Annahme:                                       */
	/* Linien muessen vorwaerts und rueckwaerts durch-  */
	/* laufen werden, da von edx ohne Ruecksicht auf    */
	/* rechts/links in edx_result abgespeichert.        */

	/* beginne mittig in reihenfolge[] */
	reihenfolge[linien_zaehler].index = ERSTE;	/* Anfang mit ERSTEr Linie */
	reihenfolge[linien_zaehler].richtung = VORWAERTS; /* per definitionem */

	/* naechster Eintrag eins weiter rechts oder links */
	lindex = linien_zaehler-1; rindex = linien_zaehler+1;

	anzahl_verkettet = 1;

	/* Kettenanfang = erster Punkt der ersten Linie */
	anfang.x = objektteil[ERSTE].knoten[ 0 ].x;
	anfang.y = objektteil[ERSTE].knoten[ 0 ].y;

	/* Kettenende = letzter Punkt der ersten Linie */
	ende.x = objektteil[ERSTE].knoten[ objektteil[ERSTE].anzahl-1 ].x;
	ende.y = objektteil[ERSTE].knoten[ objektteil[ERSTE].anzahl-1 ].y;

	objektteil[ERSTE].verkettet = 1; /* ERSTE Linie ist weg */

	/* sooft wie Linien da sind, es sei denn, in einem Lauf */
	/* werden mehr als eine Linie angekettet                */
	while (
		(anzahl_verkettet < linien_zaehler)
		&& (iterationen++ < linien_zaehler)
	) {
		/* alle Linien einmal durch */
		for (i=0; i<linien_zaehler;  i++) {
			/* Linie i ist noch frei und LinienSTART == Kettenende */
			if (
				(objektteil[i].verkettet == 0)
				&& (objektteil[i].knoten[0].x == ende.x)
				&& (objektteil[i].knoten[0].y == ende.y)
			) {
				reihenfolge[rindex].index = i;
				reihenfolge[rindex].richtung = VORWAERTS;
				rindex++; /* KEINE FEHLERABFRAGE AUF < dim(reihenfolge) !!! */
				anzahl_verkettet++;	/* eine Linie mehr */
				ende.x = objektteil[i].knoten[ objektteil[i].anzahl-1 ].x;
				ende.y = objektteil[i].knoten[ objektteil[i].anzahl-1 ].y;
				objektteil[i].verkettet = 1;
			} /* if-Zweig */

			/* Linie i ist noch frei und LinienENDE == Kettenende */
			else if (
				(objektteil[i].verkettet == 0)
				&& (objektteil[i].knoten[ objektteil[i].anzahl-1 ].x == ende.x)
				&& (objektteil[i].knoten[ objektteil[i].anzahl-1 ].y == ende.y)
			) {
				reihenfolge[rindex].index = i;
				reihenfolge[rindex].richtung = RUECKWAERTS;
				rindex++; /* KEINE FEHLERABFRAGE AUF < dim(reihenfolge) !!! */
				anzahl_verkettet++;
				ende.x = objektteil[i].knoten[ 0 ].x;
				ende.y = objektteil[i].knoten[ 0 ].y;
				objektteil[i].verkettet = 1;
			}

			/* Linie i ist noch frei und LinienENDE == Kettenanfang */
			else if (
				(objektteil[i].verkettet == 0)
				&& (objektteil[i].knoten[ objektteil[i].anzahl-1 ].x == anfang.x)
				&& (objektteil[i].knoten[ objektteil[i].anzahl-1 ].y == anfang.y)
			) {
				reihenfolge[lindex].index = i;
				reihenfolge[lindex].richtung = VORWAERTS;
				lindex--; /* KEINE FEHLERABFRAGE AUF > 0 !!! */
				anzahl_verkettet++;
				anfang.x = objektteil[i].knoten[ 0 ].x;
				anfang.y = objektteil[i].knoten[ 0 ].y;
				objektteil[i].verkettet = 1;
			}

			/* Linie i ist noch frei und LinienSTART == Kettenanfang */
			else if (
				(objektteil[i].verkettet == 0)
				&& (objektteil[i].knoten[0].x == anfang.x)
				&& (objektteil[i].knoten[0].y == anfang.y)
			) {
				reihenfolge[lindex].index = i;
				reihenfolge[lindex].richtung = RUECKWAERTS;
				lindex--; /* KEINE FEHLERABFRAGE AUF > 0 !!! */
				anzahl_verkettet++;
				anfang.x = objektteil[i].knoten[ objektteil[i].anzahl-1 ].x;
				anfang.y = objektteil[i].knoten[ objektteil[i].anzahl-1 ].y;
				objektteil[i].verkettet = 1;
			}

		} /* for-Schleife */

	} /* while-Schleife */

	/* jetzt muss reihenfolge[] ggfs. nach links geshiftet werden */
	if( lindex >= 0 ) {
		for (i=0; i<linien_zaehler;  i++) {
			reihenfolge[i].index = reihenfolge[i+lindex+1].index;
			reihenfolge[i].richtung = reihenfolge[i+lindex+1].richtung;
		}
	}		
} /* linien_verketten */


void linie_schreiben (void)
/*
 *
 *
 */
{
	int i, j;

/*      zunaechst die verketteten Objektteile in 'fp_poly' und 'fp_lx' ....*/

/*	fprintf(fp_poly, IDFORMAT "\n", aktuelle_id);	*/
	fprintf(fp_lx  , IDFORMAT "\n", aktuelle_id);

	for (i=0; i<anzahl_verkettet; i++)
	{
		if (reihenfolge[i].richtung == VORWAERTS)
		{
			for (j=0; j<objektteil[ reihenfolge[i].index ].anzahl; j++)
			{
/*				fprintf(fp_poly,         PFORMAT     , objektteil[ reihenfolge[i].index ].knoten[j].x);	*/
/*				fprintf(fp_poly, TRENNER PFORMAT "\n", objektteil[ reihenfolge[i].index ].knoten[j].y);	*/
				fprintf(fp_lx  ,         PFORMAT     , objektteil[ reihenfolge[i].index ].knoten[j].x);
				fprintf(fp_lx  , TRENNER PFORMAT "\n", objektteil[ reihenfolge[i].index ].knoten[j].y);
			}
		}
		else if (reihenfolge[i].richtung == RUECKWAERTS)
		{
			for (j = objektteil[ reihenfolge[i].index ].anzahl - 1; j>=0; j--)
			{
/*				fprintf(fp_poly, PFORMAT TRENNER, objektteil[ reihenfolge[i].index ].knoten[j].x);	*/
/*				fprintf(fp_poly, PFORMAT "\n"   , objektteil[ reihenfolge[i].index ].knoten[j].y);	*/
				fprintf(fp_lx  , PFORMAT TRENNER, objektteil[ reihenfolge[i].index ].knoten[j].x);
				fprintf(fp_lx  , PFORMAT "\n"   , objektteil[ reihenfolge[i].index ].knoten[j].y);
			}
		}
	}

/*	fprintf(fp_poly, "END\n");	*/
	fprintf(fp_lx  , "END\n");


/*      ... dann die evtl. existierenden unverketteten Objektteile in 'fp_line' und 'fp_lx' ... */ 

	if( anzahl_verkettet < linien_zaehler )
	{
		for (i=0; i<linien_zaehler; i++){
			if ( objektteil[i].verkettet == 0 )
			{
				fprintf(fp_line, IDFORMAT "\n", aktuelle_id);
				fprintf(fp_lx  , IDFORMAT "\n", aktuelle_id);
				for (j=0; j<objektteil[ i ].anzahl; j++)
				{
					fprintf(fp_line,  PFORMAT TRENNER, objektteil[ i ].knoten[j].x);
					fprintf(fp_line,  PFORMAT "\n"   , objektteil[ i ].knoten[j].y);
					fprintf(fp_lx  ,  PFORMAT TRENNER, objektteil[ i ].knoten[j].x);
					fprintf(fp_lx  ,  PFORMAT "\n"   , objektteil[ i ].knoten[j].y);
				}
                		fprintf(fp_line, "END\n");
                		fprintf(fp_lx  , "END\n");
			}
		}
        }

}	/* linie_schreiben()	*/


void polygon_schreiben (void)
/*
 *	Schreibt das aktuelle Polygon in 'fp_polygons' und 'fp_px'.
 */
{
	int i, j;

/*	fprintf(fp_polygons, IDFORMAT "\n", aktuelle_id);	*/
	fprintf(fp_px      , IDFORMAT "\n", aktuelle_id);

	for (i=0; i<anzahl_verkettet; i++) {
		if (reihenfolge[i].richtung == VORWAERTS)
		{
			for (j = 0; j<objektteil[ reihenfolge[i].index ].anzahl; j++)
			{
/*				fprintf(fp_polygons, PFORMAT TRENNER, objektteil[ reihenfolge[i].index ].knoten[j].x);	*/
/*				fprintf(fp_polygons, PFORMAT "\n"   , objektteil[ reihenfolge[i].index ].knoten[j].y);	*/
				fprintf(fp_px      , PFORMAT TRENNER, objektteil[ reihenfolge[i].index ].knoten[j].x);
				fprintf(fp_px      , PFORMAT "\n"   , objektteil[ reihenfolge[i].index ].knoten[j].y);
			}
		}
		else if (reihenfolge[i].richtung == RUECKWAERTS)
		{
			for (j = objektteil[ reihenfolge[i].index ].anzahl - 1; j>=0; j--)
			{
/*				fprintf(fp_polygons, PFORMAT TRENNER, objektteil[ reihenfolge[i].index ].knoten[j].x);	*/
/*				fprintf(fp_polygons, PFORMAT "\n"   , objektteil[ reihenfolge[i].index ].knoten[j].y);	*/
				fprintf(fp_px      , PFORMAT TRENNER, objektteil[ reihenfolge[i].index ].knoten[j].x);
				fprintf(fp_px      , PFORMAT "\n"   , objektteil[ reihenfolge[i].index ].knoten[j].y);
			}
		}
	}
/*	fprintf(fp_polygons, "END\n");	*/
	fprintf(fp_px      , "END\n");

}	/* polygon_schreiben */


int main( void )
/*
 *
 *	Hauptschleife
 *
 */
{
	IndexRichtung erstes, letztes;
	int oart;	/* temp. Speicher fuer neugelesene Objektart */


	/* Fehler- und Statistikausgabe */
	fp_err		= fopen(DOM_PATH "dom_objekte", "a");

	/* Geo-Ergebnis-Ausgabe        */
	fp_line		= fopen(DOM_PATH "dom_lines" , "a");	/* unverkettbare Linienstuecke */
/*	fp_poly		= fopen(DOM_PATH "dom_polylines", "a");	*/	/* verkettete Linien, die keinen Umring bilden */
/*	fp_polygons	= fopen(DOM_PATH "dom_polygons", "a");	*/	/* geschlossene Linienzuege */
	
	/* Ausgabe nach Objektarten */
	fp_l_alk = fopen( DOM_PATH "dom_l_alk", "a" );	/* fuer ALK */

	fp_l2 = fopen( DOM_PATH "dom_l2000", "a");	/* Polylines gem. ATKIS-Objektart */
	fp_l3 = fopen( DOM_PATH "dom_l3000", "a");
	fp_l4 = fopen( DOM_PATH "dom_l4000", "a");
	fp_l5 = fopen( DOM_PATH "dom_l5000", "a");
	fp_l6 = fopen( DOM_PATH "dom_l6000", "a");
	fp_l7 = fopen( DOM_PATH "dom_l7000", "a");
	fp_l0 = fopen( DOM_PATH "dom_lx000", "a");	/* fuer unbekannte Objektarten */

	fp_p_alk = fopen( DOM_PATH "dom_f_alk", "a" );	/* fuer ALK */

	fp_p2 = fopen( DOM_PATH "dom_f2000", "a");	/* Polygone gem. ATKIS-Objektart */
	fp_p3 = fopen( DOM_PATH "dom_f3000", "a");
	fp_p4 = fopen( DOM_PATH "dom_f4000", "a");
	fp_p5 = fopen( DOM_PATH "dom_f5000", "a");
	fp_p6 = fopen( DOM_PATH "dom_f6000", "a");
	fp_p7 = fopen( DOM_PATH "dom_f7000", "a");
	fp_p0 = fopen( DOM_PATH "dom_fx000", "a");	/* fuer unbekannte Objektarten */


	gets( satz );	/* lies erste Zeile		*/

	lies_id();	/* schreibt in neue_id		*/
	init_globals();	/* lies Objektart und ersten Objektteil	*/

	/* lies weitere Objektteile (=Linien), solange Vorrat reicht	*/
	while( gets( satz ) != NULL ) {
		pos = 0;		/* fange vorne an		*/
		
		lies_id();	/* schreibt in neue_id		*/

		/*
		 *	Falls Linie zum aktuellen Objekt gehoert,
		 *	speichere Linie in 'objektteil[]' ab und
		 *	erhoehe Zaehler.
		 */
		if( (neue_id == aktuelle_id) && (neue_tn == aktuelle_tn) )
		{
			/* ueberpruefe Objektart	*/
			oart = liefere_code();
			if( oart != objektart )	/* kommt bei ALK-Daten vor ! (11.5.95) */
						/* kommt bei ATKIS-Daten vor: 0242 und 7311 ! (15.06.95) */
			{
				printf( "Objekt-ID %ld: verschiedene Objektarten %d und %d\n", aktuelle_id, objektart, oart );
			}

			lies_punkte( linien_zaehler );
			linien_zaehler++;

		}

		/*
		 *	Falls Linie zu einem neuen Objekt gehoert,
		 *	versuche, bisheriges Objekt (in 'objektteil[]'
		 *	gespeichert) zu verketten.
		 *	Falls erfolgreich und Ring, -> Ausgabe in 'fp_polygons',
		 *	falls vollstaendig verkettet aber kein Ring, -> Ausgabe in 'fp_poly',
		 *	falls unvollstaendig verkettet, d.h. einzelne Linien derselben
		 *	Objekt-ID passen nicht zusammen, -> Ausgabe in 'fp_line'.
		 *
		 *	Diagnose-Ausgabe in 'fp_err".
		 */
		else {
			if( datenmodell == ALK ) {
				fp_lx = fp_l_alk; fp_px = fp_p_alk;
			} else {
				switch( objektart/1000 )	/* ALTE == aktuelle Objektart ! */
				{
				case 2: fp_lx = fp_l2; fp_px = fp_p2; break;
				case 3: fp_lx = fp_l3; fp_px = fp_p3; break;
				case 4: fp_lx = fp_l4; fp_px = fp_p4; break;
				case 5: fp_lx = fp_l5; fp_px = fp_p5; break;
				case 6: fp_lx = fp_l6; fp_px = fp_p6; break;
				case 7: fp_lx = fp_l7; fp_px = fp_p7; break;
				default : fp_lx = fp_l0; fp_px = fp_p0; break;
				}
			}

			linien_verketten ();

			/* unvollst. Verkettung        */
			if (anzahl_verkettet != linien_zaehler)
			{
				fprintf( fp_err, "Objekt " IDFORMAT ", Objektart " OAFORMAT, aktuelle_id, objektart );
				fprintf( fp_err, " besteht aus LINIENSTUECKEN: " );
				fprintf( fp_err, "nur %d von %d Segmente verkettet.\n", anzahl_verkettet, linien_zaehler );

                                linie_schreiben();
			}

			/* alle Objektteile verkettet  */
			else {
				erstes = reihenfolge[0];
				letztes = reihenfolge[anzahl_verkettet-1];

				/* Kette schliesst -> Polygon */
				if ( (
					(letztes.richtung == VORWAERTS)
					&& (objektteil[ letztes.index ].knoten[ objektteil[ letztes.index ].anzahl-1 ].x == objektteil[ erstes.index ].knoten[ 0 ].x)
					&& (objektteil[ letztes.index ].knoten[ objektteil[ letztes.index ].anzahl-1 ].y == objektteil[ erstes.index ].knoten[ 0 ].y)
					) || (
					(letztes.richtung == RUECKWAERTS)
					&& (objektteil[ letztes.index ].knoten[ 0 ].x == objektteil[ erstes.index ].knoten[ 0 ].x)
					&& (objektteil[ letztes.index ].knoten[ 0 ].y == objektteil[ erstes.index ].knoten[ 0 ].y)
				) ) {
					fprintf( fp_err, "Objekt " IDFORMAT ", Objektart " OAFORMAT, aktuelle_id, objektart );
					fprintf( fp_err, " ist POLYGON\n" ); 
					polygon_schreiben();
				}

				/* Kette schliesst nicht -> Linienzug */
				else {
					fprintf(fp_err, "Objekt " IDFORMAT ", Objektart " OAFORMAT, aktuelle_id, objektart );
					fprintf(fp_err, " ist POLYLINE: Ende(%d) und Anfang(%d) passen nicht zus.\n", letztes.index, erstes.index );
					linie_schreiben();
				}
			}
			init_globals();
		} /* else-Zweig */
	} /* while-Schleife */


	/* Sicherung des ALLERLETZTEN Objekts ....... */
	if( datenmodell == ALK ) {
		fp_lx = fp_l_alk; fp_px = fp_p_alk;
	} else {
		switch( objektart/1000 )	/* ALTE == aktuelle Objektart ! */
		{
		case 2: fp_lx = fp_l2; fp_px = fp_p2; break;
		case 3: fp_lx = fp_l3; fp_px = fp_p3; break;
		case 4: fp_lx = fp_l4; fp_px = fp_p4; break;
		case 5: fp_lx = fp_l5; fp_px = fp_p5; break;
		case 6: fp_lx = fp_l6; fp_px = fp_p6; break;
		case 7: fp_lx = fp_l7; fp_px = fp_p7; break;
		default : fp_lx = fp_l0; fp_px = fp_p0; break;
		}
	}

	linien_verketten ();

	/* unvollst. Verkettung        */
	if (anzahl_verkettet != linien_zaehler) {

		fprintf( fp_err, "Objekt " IDFORMAT ", Objektart " OAFORMAT, aktuelle_id, objektart );
		fprintf( fp_err, " besteht aus LINIENSTUECKEN: " );
		fprintf( fp_err, "nur %d von %d Segmente verkettet.\n", anzahl_verkettet, linien_zaehler );

                linie_schreiben();
	}

	/* alle Objektteile verkettet  */
	else {
		erstes = reihenfolge[0];
		letztes = reihenfolge[anzahl_verkettet-1];

		/* Kette schliesst -> Polygon */
		if ( (
			(letztes.richtung == VORWAERTS)
			&& (objektteil[ letztes.index ].knoten[ objektteil[ letztes.index ].anzahl-1 ].x == objektteil[ erstes.index ].knoten[ 0 ].x)
			&& (objektteil[ letztes.index ].knoten[ objektteil[ letztes.index ].anzahl-1 ].y == objektteil[ erstes.index ].knoten[ 0 ].y)
			) || (
			(letztes.richtung == RUECKWAERTS)
			&& (objektteil[ letztes.index ].knoten[ 0 ].x == objektteil[ erstes.index ].knoten[ 0 ].x)
			&& (objektteil[ letztes.index ].knoten[ 0 ].y == objektteil[ erstes.index ].knoten[ 0 ].y)
		) ) {
			fprintf( fp_err, "Objekt " IDFORMAT ", Objektart " OAFORMAT, aktuelle_id, objektart );
			fprintf( fp_err, " ist POLYGON\n" ); 
			polygon_schreiben();
		}

		/* Kette schliesst nicht -> Linienzug */
		else {
			fprintf(fp_err, "Objekt " IDFORMAT ", Objektart " OAFORMAT, aktuelle_id, objektart );
			fprintf(fp_err, " ist POLYLINE: Ende(%d) und Anfang(%d) passen nicht zus.\n", letztes.index, erstes.index );
			linie_schreiben();
		}
	}

	fclose(fp_err);

	fclose(fp_line);	/* allerletztes (Doppel-)END muss	*/
/*	fclose(fp_poly);	*/	/* durch 'EDXRUN' geschrieben werden	*/
/*	fclose(fp_polygons);	*/

	fclose(fp_l0);
	fclose(fp_l2);	fclose(fp_l3);
	fclose(fp_l4);	fclose(fp_l5);
	fclose(fp_l6);	fclose(fp_l7);
	fclose(fp_l_alk);

	fclose(fp_p0);
	fclose(fp_p2);	fclose(fp_p3);
	fclose(fp_p4);	fclose(fp_p5);
	fclose(fp_p6);	fclose(fp_p7);
	fclose(fp_p_alk);


	return 0;
} /* main */
