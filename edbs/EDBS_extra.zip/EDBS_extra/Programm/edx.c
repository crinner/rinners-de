/*
	Programm EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format

	Modul edx.c

	Copyright (C) 1995 Claus Rinner

	Version: 2.0 / ATKIS
	Stand: 01.06.1995

	Dieses Programm ist freie Software. Sie k�nnen es unter
	den Bedingungen der GNU General Public License, wie von der
	Free Software Foundation herausgegeben, weitergeben und/oder
	modifizieren, entweder unter Version 2 der Lizenz oder (wenn
	Sie es w�nschen) jeder sp�teren Version.

	Die Ver�ffentlichung dieses Programms erfolgt in der
	Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
	GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
	der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
	Details finden Sie in der GNU General Public License.

	Sie sollten eine Kopie der GNU General Public License zusammen
	mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
	an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
	MA 02139, USA.
 */

#include "edx.h"	/* nummer2id() */
#include "edbs.h"	/* lies_edbs() */
#include "admini.h"	/* u.a. auftragskennung(), ... */
#include "grundriss.h"
#include "attribut.h"
#include "fp_edx.h"

#include <stdio.h>

#define MAX_UNDEFINIERT	5

extern int satz_zaehler;	/* Anzahl gelesene EDBS-Saetze */


long unsigned int nummer2id( char* nr )
/*
 *	konvertiert 5 letzten Zeichen aus aktuelle_nummer
 *	in long unsigned integer
 *	Grund fuer die Beschraenkung auf 5 Zeichen:
 *	ARC/INFO - Data Models, Concepts & Key Terms, Seite B-3:
 *		"User-IDs are stored as 4-byte binary integers
 *		and can range from +-1 to +-2147483647."
 */
{
	long unsigned rval = 0;
        int l = strlen(nr)-1;

        if (l >= 5) {
          rval = (nr[l]-48) + (nr[l-1]-48)*45 + (nr[l-2]-48)*2025 + (nr[l-3]-48)*91125 + (nr[l-4]-48)*2025*2025;
          return rval; }
        else
          return 0;
} /* ******* nummer2id ******* */


int main( void )
{
	int undefiniert = 0;	/* Zaehler fuer nicht identifizierte EDBS-Satzarten */
	int n;	/* Wiederholungsfaktor fuer den kompletten EDBS-Parameter 'Inhalt */
		/* der Information'; ist unabhaengig von der Satzart immer = 1 */

	/* Programmname etc. ausgeben	*/
	/* CR 2000-03-10		*/
	fprintf( stderr, "\nEDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format\n" );
	fprintf( stderr, "Version 2.0\n" );
	fprintf( stderr, "Copyright (C) 1995-2001 Claus Rinner\n\n" );
	fprintf( stderr, "Dieses Programm ist freie Software unter der GNU General Public License.\n" );
	fprintf( stderr, "Die Veroeffentlichung dieses Programms erfolgt in der Hoffnung, \n" );
	fprintf( stderr, "dass es Ihnen von Nutzen sein wird, aber OHNE JEDE GEWAEHRLEISTUNG \n" );
	fprintf( stderr, " - sogar ohne die implizite Gewaehrleistung der MARKTREIFE oder der \n" );
	fprintf( stderr, "EIGNUNG FUER EINEN BESTIMMTEN ZWECK.\n\n" );

	/* Oeffnen der edx-Ausgabe-Dateien */
	fp_open();

	/* Endlosschleife zum Einlesen und Bearbeiten der EDBS-Saetze;			*/
	/* Abbruch der Schleife bei Auftragsendesatz oder				*/
	/* mehr als MAX_UNDEFINIERT-maligem Auftreten der Satzart UNDEFINIERT oder	*/
	/* bei Satzart ABBRUCH oder nicht definierter Satzart (default: ... )		*/
	do
	{
		switch( lies_edbs() )
		{
			case AUFTRAGSKENNSATZ:
				printf( "\n\nSatz Nr. %d: Auftragskennsatz\n", satz_zaehler );
				auftragskennung();
				break;
			case GEBIETSKENNZEICHNUNG:
				printf( "\n\nSatz Nr. %d: Gebietskennzeichnung\n", satz_zaehler );
				gebietskennzeichnung();
				break;
			case AUFTRAGSKENNDATEN:
				printf( "\n\nSatz Nr. %d: Auftragskenndaten\n", satz_zaehler );
			case AUFTRAGSTEXTDATEN:
				printf( "\n\nSatz Nr. %d: Auftragstextdaten\n", satz_zaehler );
				n = lies_whf();
				while( n-- > 0 ) auftragstext();
				break;
			case OBJEKTDATEN:
				printf( "\n\nSatz Nr. %d: Objektdaten\n", satz_zaehler );
				n = lies_whf();
				while( n-- > 0 ) grundrisskennzeichen();
				break;
			case ATTRIBUTE:
				printf( "\n\nSatz Nr. %d: Attribute\n", satz_zaehler );
				n = lies_whf();
				while( n-- > 0 ) attributkennzeichen();
				break;
			case AUFTRAGSENDE:
				printf( "\n\nSatz Nr. %d: Auftragsende\n", satz_zaehler );
				fp_close();
				exit( 0 );
				break;
			case UNDEFINIERT:
				fprintf( stderr, "Die Satzart der Inputzeile Nr. %d", satz_zaehler );
				fprintf( stderr, "konnte nicht identifiziert werden: \n" );
				schreibe_satz();
				fprintf( stderr, "\nDer Satz wurde nicht bearbeitet !\n" );
				if( undefiniert++ > MAX_UNDEFINIERT ) {
					fprintf( stderr, "\n\nZuviele Einlese-Fehler !\n" );
					exit( 1 );
				}
				break;
			default:
				fprintf( stderr, "\n\nIrregulaerer Programmabbruch !!!\n" );
				exit( 1 );
		}

	} while( 1 );

	fprintf( stderr, "\n\nDiese Stelle kann nie erreicht werden\n" );
	return 0;
}
