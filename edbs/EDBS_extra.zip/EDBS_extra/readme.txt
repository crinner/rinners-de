EDBS_extra - Reader fuer ATKIS/ALK-Daten im EDBS-Format
Version: 2.0 / ATKIS + ALK

Copyright (C) 1995-2001 Claus Rinner, claus@rinners.de

Bitte konsultieren Sie die Dokumentation auf http://www.rinners.de/edbs/.
Hier ein paar typische Befehlsfolgen:

# Kompilieren des Tools auf Ihrer Plattform
make

# Anlegen der Zielverzeichnisse
mkdir edx_files
mkdir dom_files

# Konvertieren der Datei "atkis.bsp"
./edx.exe < atkis.bsp > /dev/null		# Erstellen der edx-Ergebnisdateien
sort -o dom_files/edx_linien_sorted edx_files/edx_linien	# Sortieren nach Objekt-ID
./dom.exe < dom_files/edx_linien_sorted				# Verketten der Linienz�ge

# L�schen fr�herer Konvertierungsergebnisse vor erneutem Lauf
rm edx_files/*
rm dom_files/*

Weitere Skripte befinden sich im entsprechenden Unterverzeichnis der Distribution.
